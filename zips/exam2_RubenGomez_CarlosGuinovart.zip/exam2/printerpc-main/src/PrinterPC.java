public interface PrinterPC {
    /**
     * Add a new print to the queue, returns a message if this succeeded or not.
      * @param printName
     * @param material
     * @param colors
     * @return
     */
    public String addPrintToQueue(String printName, String material, String[] colors);

    /**
     * Get the list of active prints showing id, name and time remaining.
     * @return
     */
    public String[] getActivePrints();

    /**
     * Get the list of completed prints.
     * @return
     */
    public String[] getCompletedPrints();

    /**
     * Start the printers
     */
    public void startPrinters();

    /**
     * Stop the printers
     */
    public void stopPrinters();
}
