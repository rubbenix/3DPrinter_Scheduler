package nl.saxion.Models;

public enum FilamentType {
    PLA, PETG, ABS
}
