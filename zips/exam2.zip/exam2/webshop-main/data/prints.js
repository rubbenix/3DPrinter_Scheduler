module.exports = [
    {
        name: "Acoustic Guitar Cooky Cutter",
        nrColors: 1
    },
    {
        name: "Stegosaurus Pickholder",
        nrColors: 1
    },
    {
        name: "Collapsing Jian",
        nrColors: 1
    },
    {
        name: "Fucktopus",
        nrColors: 1
    },
    {
        name: "Moon Lamp",
        nrColors: 1
    },
    {
        name: "Earth Globe",
        nrColors: 4
    },
    {
        name: "Cathedral",
        nrColors: 3
    },
    {
        name: "Lizard",
        nrColors: 2
    },
    {
        name: "Tree Frog",
        nrColors: 2
    }
]