module.exports = [
    {
        id: 1,
        customer: 1,
        status: "new",
        print: "Acoustic Guitar Cooky Cutter",
        colors: ["Blue"],
        material: "PLA",
        shipping: "Mail"
    },
    {
        id: 2,
        customer: 2,
        status: "new",
        print: "Moon Lamp",
        colors: ["White"],
        material: "PLA",
        shipping: "Pickup Amsterdam"
    }
]