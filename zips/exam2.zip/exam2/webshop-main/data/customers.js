module.exports = [
    {
        name: "Jan Jaap Sandee",
        id: 1
    },
    {
        name: "Kevin Wilmink",
        id: 2
    },
    {
        name: "Dick Heijink",
        id: 3
    },
    {
        name: "Richard Bevers",
        id: 4
    }
];