package Models;

public record Print(String name, int time, int nrColors) {}