package Data;

import Models.Print;

import java.util.List;

public interface PrintLoader {
    public List<Print> getPrintList();
}
